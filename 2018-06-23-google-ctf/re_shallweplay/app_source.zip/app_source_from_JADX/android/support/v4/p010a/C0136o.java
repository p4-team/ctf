package android.support.v4.p010a;

import java.util.List;

public class C0136o {
    private final List<C0114h> f622a;
    private final List<C0136o> f623b;

    C0136o(List<C0114h> list, List<C0136o> list2) {
        this.f622a = list;
        this.f623b = list2;
    }

    List<C0114h> m753a() {
        return this.f622a;
    }

    List<C0136o> m754b() {
        return this.f623b;
    }
}
