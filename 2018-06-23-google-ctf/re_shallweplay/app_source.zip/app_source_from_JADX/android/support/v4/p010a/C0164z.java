package android.support.v4.p010a;

import android.util.AndroidRuntimeException;

final class C0164z extends AndroidRuntimeException {
    public C0164z(String str) {
        super(str);
    }
}
