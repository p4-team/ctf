package android.support.v4.p017h;

import android.view.View;
import android.view.ViewGroup;

public class C0301m {
    private final ViewGroup f926a;
    private int f927b;

    public C0301m(ViewGroup viewGroup) {
        this.f926a = viewGroup;
    }

    public int m1322a() {
        return this.f927b;
    }

    public void m1323a(View view) {
        m1324a(view, 0);
    }

    public void m1324a(View view, int i) {
        this.f927b = 0;
    }

    public void m1325a(View view, View view2, int i) {
        m1326a(view, view2, i, 0);
    }

    public void m1326a(View view, View view2, int i, int i2) {
        this.f927b = i;
    }
}
