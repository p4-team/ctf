package android.support.v4.p016g;

public class C0243j {
    public static <T> T m1166a(T t) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException();
    }
}
