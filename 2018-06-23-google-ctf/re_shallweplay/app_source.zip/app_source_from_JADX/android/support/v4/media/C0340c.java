package android.support.v4.media;

import android.media.MediaMetadata;
import android.os.Parcel;

class C0340c {
    public static void m1499a(Object obj, Parcel parcel, int i) {
        ((MediaMetadata) obj).writeToParcel(parcel, i);
    }
}
