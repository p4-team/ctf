package android.support.v4.media.session;

import android.media.session.PlaybackState;
import android.os.Bundle;

class C0367f {
    public static Bundle m1709a(Object obj) {
        return ((PlaybackState) obj).getExtras();
    }
}
