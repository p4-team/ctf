package android.support.v7.app;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.Window;

class C0444h extends C0443k {
    C0444h(Context context, Window window, C0430d c0430d) {
        super(context, window, c0430d);
    }

    View mo313a(View view, String str, Context context, AttributeSet attributeSet) {
        return null;
    }
}
