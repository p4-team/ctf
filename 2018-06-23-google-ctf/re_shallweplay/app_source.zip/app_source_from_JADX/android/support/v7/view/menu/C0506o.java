package android.support.v7.view.menu;

import android.content.Context;

public interface C0506o {

    public interface C0459a {
        void mo321a(C0521h c0521h, boolean z);

        boolean mo322a(C0521h c0521h);
    }

    void mo402a(Context context, C0521h c0521h);

    void mo403a(C0521h c0521h, boolean z);

    void mo404a(C0459a c0459a);

    boolean mo405a(C0521h c0521h, C0524j c0524j);

    boolean mo406a(C0539u c0539u);

    void mo407b(boolean z);

    boolean mo408b();

    boolean mo409b(C0521h c0521h, C0524j c0524j);
}
