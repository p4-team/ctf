package android.support.v7.widget;

import android.content.res.Resources.Theme;
import android.widget.SpinnerAdapter;

public interface as extends SpinnerAdapter {
    Theme m2946a();

    void m2947a(Theme theme);
}
