package android.support.v7.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;

class au {
    public ColorStateList f2127a;
    public Mode f2128b;
    public boolean f2129c;
    public boolean f2130d;

    au() {
    }

    void m2950a() {
        this.f2127a = null;
        this.f2130d = false;
        this.f2128b = null;
        this.f2129c = false;
    }
}
