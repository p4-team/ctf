package android.support.v7.widget;

import android.support.v7.view.menu.C0521h;
import android.view.MenuItem;

public interface al {
    void mo410a(C0521h c0521h, MenuItem menuItem);

    void mo411b(C0521h c0521h, MenuItem menuItem);
}
