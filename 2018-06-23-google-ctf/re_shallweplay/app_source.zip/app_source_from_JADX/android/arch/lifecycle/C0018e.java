package android.arch.lifecycle;

@Deprecated
public interface C0018e extends C0014c {
    C0017d m35b();
}
