package android.arch.lifecycle;

import android.arch.lifecycle.C0013b.C0011a;

public interface C0010a {
    void mo2a(C0014c c0014c, C0011a c0011a);
}
