package android.arch.p000a.p001a;

import android.arch.p000a.p001a.C0000b.C0006c;
import java.util.HashMap;

public class C0001a<K, V> extends C0000b<K, V> {
    private HashMap<K, C0006c<K, V>> f4a = new HashMap();

    public boolean m6a(K k) {
        return this.f4a.containsKey(k);
    }
}
