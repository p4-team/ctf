#!/usr/bin/python3
from selenium import webdriver  
from selenium.webdriver.common.keys import Keys  
from selenium.webdriver.chrome.options import Options 
import os
import time
import traceback
chrome_options = Options()
chrome_options.headless = True
chrome_options.add_argument('--no-sandbox')


while True:
    try:
        driver = webdriver.Chrome("/chromedriver", options=chrome_options)  
        driver.set_page_load_timeout(30)
        driver.get("http://frontend/")
        time.sleep(1)
        driver.add_cookie({"name": "VIP_CODE", "value":os.environ.get("VIP_CODE"),"httpOnly": True})
        driver.get("http://frontend/")
        time.sleep(30)
        driver.close()
    except:
        traceback.print_exc()
