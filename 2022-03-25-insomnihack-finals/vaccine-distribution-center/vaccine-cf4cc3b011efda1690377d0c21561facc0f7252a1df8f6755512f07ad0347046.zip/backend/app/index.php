
<!DOCTYPE html>
<html>
<head>
	<title>CoronaVaccine Distribution Center</title>
	<script>

		var identity = '<?php print(preg_replace("/[^a-z0-9_]+/i","",$_SERVER['HTTP_X_WHOAMI']));?>';
		<?php
			if($_COOKIE['VIP_CODE'] === getenv("VIP_CODE")) {
				print("var isvip = true;");
				print("var vaccine = '" . getenv("FLAG")."';");
			}
			else {
				print("var isvip = false;");
				print("var vaccine = 'none';");
			}
		?>
	</script>
	<style>
		body {
			background-color: black;
			background-image: url(background.png);
			background-repeat: no-repeat;
			background-position: center;
			color: white;
			font-family: verdana
			margin: 0 auto;
			text-align: center;
		}
		
	</style>
</head>
<body>
<h1 style="margin-top: 600px;">
Please wait in line until we deliver the vaccine!
</h1>
<h2>
We do not have enough vaccine for everyone, so only VIPs can get our product for the time being.
</h2>
<script>
	function getScript() {
		var s = document.createElement("script");
		s.setAttribute("src","./script.js");
		document.body.appendChild(s);
	}
	setTimeout("getScript()",10000);
</script>
</body>
</html>
