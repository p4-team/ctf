if (!isvip || Date.now() < new Date("2022-06-06")) {
	//only VIPs get vaccine, and only when we decide
	document.location = 'https://insomnihack.ch/';
}


function getVaccine() {
fetch('http://'+identity+'/?vaccine='+vaccine)
	.then((response) => {
	console.log(response.json());
	});
}

//OK, it's time to give you the vaccine!
setTimeout("getVaccine()",1000);
